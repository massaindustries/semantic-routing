"""
Test audio-only requests (STT via faster-whisper) – base64 version.
"""
import os
from dotenv import load_dotenv
load_dotenv()

import requests
import base64
from pathlib import Path

# Endpoint for audio transcription (base64 version)
API_URL = "http://213.171.186.210:8000/v1/chat/completions"

def call_brick(payload_path: Path):
    """
    Base64‑only version:
    - Reads the audio file.
    - Encodes it in base64.
    - Sends a JSON payload to the /v1/chat/completions endpoint.
    """
    api_key = os.getenv('REGOLO_API_KEY', '')
    # Convert audio file to base64
    with payload_path.open('rb') as audio_file:
        audio_b64 = base64.b64encode(audio_file.read()).decode('utf-8')
    payload = {
        "model": "brick",
        "messages": [{
            "role": "user",
            "content": [{
                "type": "audio",
                "audio": f"data:audio/mp3;base64,{audio_b64}"
            }]
        }],
        "language": "en",
        "stream": False,
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    response = requests.post(API_URL, json=payload, headers=headers, timeout=120)
    return response

def print_response(response):
    print(f"Status: {response.status_code}")
    try:
        print(response.text)
    except Exception:
        print("No text response")

def main():
    audio_path = Path("/home/rdseeweb/regolo-semantic-routing/public/testaudio.mp3")
    if not audio_path.is_file():
        print(f"Audio file not found: {audio_path}")
        return
    response = call_brick(audio_path)
    print_response(response)

if __name__ == "__main__":
    if not os.getenv("REGOLO_API_KEY"):
        print("Warning: REGOLO_API_KEY not set. Request will fail.")
    else:
        main()
