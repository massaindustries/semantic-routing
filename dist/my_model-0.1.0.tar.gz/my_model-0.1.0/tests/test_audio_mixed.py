"""
Test audio + text requests (STT → LLM).
"""
import os
from dotenv import load_dotenv
load_dotenv()

import requests
import json

BRICK_API_URL = "http://213.171.186.210:8000/v1/chat/completions"


def call_brick(payload):
    headers = {
        "Authorization": f"Bearer {os.getenv('REGOLO_API_KEY', '')}",
        "Content-Type": "application/json",
    }
    response = requests.post(BRICK_API_URL, json=payload, headers=headers, timeout=120)
    response.raise_for_status()
    return response.json()


def print_response(result, title="Response"):
    print(f"\n{title}:")
    print(json.dumps(result, indent=2, ensure_ascii=False))


def main():
    # Using dummy base64 data for testing the endpoint
    audio_bytes = "dGVzdCBhdWRpbw=="  # dummy base64
    
    payload = {
        "model": "brick",
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": "Summarize the following transcription."},
                {"type": "input_audio", "audio_url": {"url": f"data:audio/mp3;base64,{audio_bytes}"}}
            ]
        }],
        "stream": False,
    }
    
    print("Sending audio+mixed request (STT → LLM)...")
    result = call_brick(payload)
    print_response(result, "Mixed Audio Response")


if __name__ == "__main__":
    if not os.getenv("REGOLO_API_KEY"):
        print("Warning: REGOLO_API_KEY not set. Request will fail.")
    else:
        main()
