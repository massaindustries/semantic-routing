"""
Test audio-only requests (STT via faster-whisper).
"""
import os
from dotenv import load_dotenv
load_dotenv()

import requests
from pathlib import Path

BRICK_API_URL = "http://213.171.186.210:8000/v1/chat/completions"


def main():
    api_key = os.getenv("REGOLO_API_KEY", "")
    
    AUDIO_FILE = "/home/rdseeweb/regolo-semantic-routing/public/testaudio.mp3"

    audio_path = Path(AUDIO_FILE)
    if not audio_path.is_file():
        print(f"Audio file does not exist: {audio_path}")
        return

    headers = {
        "Authorization": f"Bearer {api_key}",
    }

    with audio_path.open("rb") as audio_file:
        files = {
            "file": (audio_path.name, audio_file, "application/octet-stream")
        }
        data = {
            "model": "brick",
            "language": "en",
            "response_format": "text",
        }

        response = requests.post(BRICK_API_URL, headers=headers, data=data, files=files)

    if response.status_code == 200:
        transcript_text = response.text
        print("=== Transcription ===")
        print(transcript_text)
        print("=====================")
    else:
        print("Failed transcription request:")
        print("Status code:", response.status_code)
        print("Response body:", response.text)


if __name__ == "__main__":
    if not os.getenv("REGOLO_API_KEY"):
        print("Warning: REGOLO_API_KEY not set. Request will fail.")
    else:
        main()
