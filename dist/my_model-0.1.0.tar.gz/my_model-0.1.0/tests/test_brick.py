"""
Test text, image, audio payloads structure.
"""
import json


def test_text_payload():
    """Test that text payload is correctly built."""
    payload = {
        "model": "brick",
        "messages": [{"role": "user", "content": "Hello"}],
        "stream": False
    }
    assert payload["model"] == "brick"
    assert len(payload["messages"]) == 1
    assert payload["messages"][0]["content"] == "Hello"


def test_image_payload():
    """Test that image payload is correctly built."""
    payload = {
        "model": "brick",
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": "Analyze this image"},
                {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,abc"}}
            ]
        }],
        "stream": False
    }
    assert payload["model"] == "brick"
    assert len(payload["messages"][0]["content"]) == 2


def test_audio_payload():
    """Test that audio payload is correctly built."""
    payload = {
        "model": "brick",
        "messages": [{
            "role": "user",
            "content": [{"type": "input_audio", "audio_url": {"url": "data:audio/mp3;base64,abc"}}]
        }],
        "language": "en",
        "stream": False
    }
    assert payload["model"] == "brick"
    assert payload["language"] == "en"
