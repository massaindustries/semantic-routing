"""
Test that the brick model is available in the models list.
"""
import os
import requests
import json

BRICK_API_URL = "http://213.171.186.210:8000/v1/models"


def get_models():
    headers = {"Authorization": f"Bearer {os.getenv('REGOLO_API_KEY', '')}"}
    response = requests.get(BRICK_API_URL, headers=headers, timeout=30)
    response.raise_for_status()
    return response.json()


def test_get_models_returns_brick():
    resp = get_models()
    assert resp.get("object") == "list"
    ids = [m.get("id") for m in resp.get("data", [])]
    assert "brick" in ids
